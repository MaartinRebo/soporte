<?php
session_start();
$usuarioOk = false;
$hayDatos = isset($_POST["usuario"]);

if ($hayDatos) {
    $login = $_POST["usuario"];
    $contrasinal = $_POST["password"];
    $base_dn = "dc=martinrebo,dc=mro";
    $ldap_host = "ldaps://serverwindows.martinrebo.mro";

    // Cargar usuario y contraseña de búsqueda LDAP
    $ldap_creds = require('/etc/miweb/websearch.php');
    $ldap_user = $ldap_creds['ldap_user'];
    $ldap_pass = $ldap_creds['ldap_pass'];

    // 1. Buscar el DN del usuario
    $ldapconn = ldap_connect($ldap_host);
    ldap_set_option($ldapconn, LDAP_OPT_PROTOCOL_VERSION, 3);
    ldap_set_option($ldapconn, LDAP_OPT_REFERRALS, 0);

    if (@ldap_bind($ldapconn, $ldap_user, $ldap_pass)) {
        $ldap_base = "cn=users,cn=accounts,$base_dn";
        $filtro = "(uid=$login)";
        $search = @ldap_search($ldapconn, $ldap_base, $filtro, ["dn"]);
        $info = ldap_get_entries($ldapconn, $search);

        if ($info["count"] == 1) {
            $user_dn = $info[0]["dn"];

            // 2. Comprobar que el usuario pertenece al grupo webadmins
            $ldap_group_base = "cn=groups,cn=accounts,$base_dn";
            $filtroGrupo = "(&(objectClass=posixGroup)(cn=webadmins)(member=$user_dn))";
            $searchGrupo = @ldap_search($ldapconn, $ldap_group_base, $filtroGrupo, ["cn"]);
            $infoGrupo = ldap_get_entries($ldapconn, $searchGrupo);

            if ($infoGrupo["count"] > 0) {
                // 3. Validar la contraseña del usuario (bind simple)
                if (@ldap_bind($ldapconn, $user_dn, $contrasinal)) {
                    // 4. Validar acceso a MySQL
                    $conexion = new mysqli("192.168.222.4", "martin", $contrasinal, "soportetecnico");
                    if ($conexion && !$conexion->connect_error) {
                        $_SESSION["admin"] = true;
                        $_SESSION["usuario"] = $login;
                        $conexion->close();
                        ldap_close($ldapconn);
                        header("Location: admin_panel.php");
                        exit;
                    } else {
                        $error = "Contraseña de base de datos incorrecta.";
                    }
                } else {
                    $error = "Contraseña LDAP incorrecta.";
                }
            } else {
                $error = "No tienes permisos de administrador.";
            }
        } else {
            $error = "Usuario no encontrado.";
        }
        ldap_close($ldapconn);
    } else {
        $error = "Error de autenticación con el usuario de búsqueda LDAP.";
    }
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Acceso Administrador</title>
    <link rel="stylesheet" href="estiloLogin.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
    <main class="container d-flex flex-column justify-content-center align-items-center" style="max-height: 95vh;">
        <div class="text-center">
            <a href="index.html"><img src="imgr/cruzTech2.webp" alt="Icono soporte" id="img1" style="max-width: 33vh; max-height: 45vw;"></a>
            <h1 class="text-center mb-3 fs-1">Soporte Técnico</h1>
        </div>
        <div class="card p-5 shadow text-center">
            <h2 class="text-center mb-4 fs-3">Acceso Administrador</h2>
            <?php if (!empty($error)): ?>
                <div class="alert alert-danger text-center"><?= htmlspecialchars($error) ?></div>
            <?php endif; ?>
            <form method="post" action="login.php" class="mb-3" autocomplete="off">
                <div class="mb-4">
                    <label for="usuario" class="form-label fs-5">Usuario</label>
                    <input type="text" class="form-control" id="usuario" name="usuario" placeholder="Escribe tu usuario" required>
                </div>
                <div class="mb-4">
                    <label for="password" class="form-label fs-5">Contraseña</label>
                    <input type="password" class="form-control" id="password" name="password" placeholder="Escribe tu contraseña" required>
                </div>
                <div class="text-center">
                    <button type="submit" class="btn btn-primary w-100">Iniciar Sesión</button>
                </div>
            </form>
        </div>
    </main>
</body>
</html>