<?php
session_start();
if (!isset($_SESSION['admin'])) {
    header("Location: login.php");
    exit;
}

$id = $_GET['id'] ?? null;
if (!$id) {
    header("Location: admin_panel.php");
    exit;
}

$conexion = new mysqli("192.168.222.4", "martin", "Martin27", "soportetecnico");
if ($conexion->connect_error) {
    die("Error de conexión: " . $conexion->connect_error);
}

// 1. Obtener la ruta del archivo asociado
$stmt = $conexion->prepare("SELECT archivo FROM tickets WHERE id=?");
$stmt->bind_param("i", $id);
$stmt->execute();
$stmt->bind_result($archivo);
$stmt->fetch();
$stmt->close();

// 2. Eliminar el registro de la base de datos
$stmt = $conexion->prepare("DELETE FROM tickets WHERE id=?");
$stmt->bind_param("i", $id);
$stmt->execute();
$stmt->close();
$conexion->close();

// 3. Eliminar el archivo físico si existe y no es nulo
if ($archivo && file_exists($archivo)) {
    unlink($archivo);
}

header("Location: admin_panel.php");
exit;