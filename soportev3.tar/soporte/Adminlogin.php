<?php
session_start();

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $usuario = $_POST['correo'] ?? '';
    $password = $_POST['password'] ?? '';

    if ($usuario === "martin@rebo.com" && $password === "Martin27") {
        $_SESSION['admin'] = true;
        header("Location: admin_panel.php");
        exit;
    } else {
        $error = "Usuario o contraseña incorrectos.";
    }
}
?>