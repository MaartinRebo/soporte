<?php
session_start();
$usuarioOk = false;
$hayDatos = isset($_POST["usuario"]);

if ($hayDatos) {
    $login = $_POST["usuario"];
    $contrasinal = $_POST["password"];
    $base_dn = "dc=martinrebo,dc=mro";
    $ldap_host = "ldaps://ipa.martinrebo.mro";

    // 1. Buscar el DN del usuario usando GSSAPI
    $login_escaped = escapeshellarg($login);
    $cmd_dn = "ldapsearch -Y GSSAPI -H $ldap_host -b 'cn=users,cn=accounts,$base_dn' '(uid=$login)' dn -LLL";
    $output_dn = [];
    exec($cmd_dn, $output_dn, $ret_dn);

    $user_dn = null;
    foreach ($output_dn as $line) {
        if (stripos($line, "dn: ") === 0) {
            $user_dn = trim(substr($line, 4));
            break;
        }
    }

    if ($user_dn) {
        // 2. Comprobar que el usuario pertenece al grupo webadmins usando GSSAPI
        $group_filter = escapeshellarg("(&(cn=webadmins)(member=$user_dn))");
        $cmd_group = "ldapsearch -Y GSSAPI -H $ldap_host -b 'cn=groups,cn=accounts,$base_dn' $group_filter dn -LLL";
        $output_group = [];
        exec($cmd_group, $output_group, $ret_group);

        $is_webadmin = false;
        foreach ($output_group as $line) {
            if (stripos($line, "dn: ") === 0) {
                $is_webadmin = true;
                break;
            }
        }

        if ($is_webadmin) {
            // 3. Validar acceso a MySQL con la contraseña proporcionada
            $conexion = new mysqli("192.168.222.4", "martin", $contrasinal, "soportetecnico");
            if ($conexion && !$conexion->connect_error) {
                $_SESSION["admin"] = true;
                $_SESSION["usuario"] = $login;
                $conexion->close();
                header("Location: admin_panel.php");
                exit;
            } else {
                $error = "Contraseña de base de datos incorrecta.";
            }
        } else {
            $error = "No tienes permisos de administrador.";
        }
    } else {
        $error = "Usuario no encontrado.";
    }
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Acceso Administrador</title>
    <link rel="stylesheet" href="estiloLogin.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
    <main class="container d-flex flex-column justify-content-center align-items-center" style="max-height: 95vh;">
        <div class="text-center">
            <a href="index.html"><img src="imgr/cruzTech2.webp" alt="Icono soporte" id="img1" style="max-width: 33vh; max-height: 45vw;"></a>
            <h1 class="text-center mb-3 fs-1">Soporte Técnico</h1>
        </div>
        <div class="card p-5 shadow text-center">
            <h2 class="text-center mb-4 fs-3">Acceso Administrador</h2>
            <?php if (!empty($error)): ?>
                <div class="alert alert-danger text-center"><?= htmlspecialchars($error) ?></div>
            <?php endif; ?>
            <form method="post" action="login.php" class="mb-3" autocomplete="off">
                <div class="mb-4">
                    <label for="usuario" class="form-label fs-5">Usuario</label>
                    <input type="text" class="form-control" id="usuario" name="usuario" placeholder="Escribe tu usuario" required>
                </div>
                <div class="mb-4">
                    <label for="password" class="form-label fs-5">Contraseña</label>
                    <input type="password" class="form-control" id="password" name="password" placeholder="Escribe tu contraseña" required>
                </div>
                <div class="text-center">
                    <button type="submit" class="btn btn-primary w-100">Iniciar Sesión</button>
                </div>
            </form>
        </div>
    </main>
</body>
</html>