<?php
session_start();

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $usuario = $_POST['correo'] ?? '';
    $password = $_POST['password'] ?? '';

    // Configuración LDAP FreeIPA
    $ldap_host = "ldap://192.168.222.2";
    $ldap_port = 389; // Usa 636 si tienes LDAPS
    // Ajusta el DN base a tu dominio:
    $ldap_dn = "uid=$usuario,cn=users,cn=accounts,dc=martinrebo,dc=mro";

    $ldapconn = ldap_connect($ldap_host, $ldap_port);
    if ($ldapconn) {
        ldap_set_option($ldapconn, LDAP_OPT_PROTOCOL_VERSION, 3);
        // Autenticación
        if (@ldap_bind($ldapconn, $ldap_dn, $password)) {
            $_SESSION['admin'] = true;
            header("Location: admin_panel.php");
            exit;
        } else {
            $error = "Usuario o contraseña incorrectos (LDAP).";
        }
        ldap_close($ldapconn);
    } else {
        $error = "No se pudo conectar al servidor LDAP.";
    }
}
?>